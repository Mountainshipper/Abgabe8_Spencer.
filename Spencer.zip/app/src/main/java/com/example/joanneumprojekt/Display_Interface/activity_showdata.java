/**
 * Show data for main screen
 */

package com.example.joanneumprojekt.Display_Interface;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.joanneumprojekt.R;

public class activity_showdata extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.showdata);
    }
}