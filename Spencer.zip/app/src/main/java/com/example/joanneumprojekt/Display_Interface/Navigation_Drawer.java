/**
 * Class for navigation menu
 */

package com.example.joanneumprojekt.Display_Interface;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.joanneumprojekt.R;

public class Navigation_Drawer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_drawer);
    }
}